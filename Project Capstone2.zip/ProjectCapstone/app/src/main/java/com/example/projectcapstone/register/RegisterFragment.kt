package com.example.projectcapstone.register

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.text.InputType
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import androidx.navigation.fragment.findNavController
import com.example.projectcapstone.R

class RegisterFragment : Fragment() {
    private lateinit var fullNameEditText: EditText
    private lateinit var registerEmailEditText: EditText
    private lateinit var registerPasswordEditText: EditText
    private lateinit var confirmPasswordEditText: EditText
    private lateinit var registerSubmitButton: Button
    private lateinit var loginButton: Button
    private lateinit var showRegisterPasswordButton: ImageButton
    private lateinit var showConfirmPasswordButton: ImageButton

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_register, container, false)
        fullNameEditText = view.findViewById(R.id.fullNameEditText)
        registerEmailEditText = view.findViewById(R.id.registerEmailEditText)
        registerPasswordEditText = view.findViewById(R.id.registerPasswordEditText)
        confirmPasswordEditText = view.findViewById(R.id.confirmPasswordEditText)
        showRegisterPasswordButton = view.findViewById(R.id.showRegisterPasswordButton)
        showConfirmPasswordButton = view.findViewById(R.id.showConfirmPasswordButton)
        registerSubmitButton = view.findViewById(R.id.submitRegisterButton)
        loginButton = view.findViewById(R.id.loginButton)


        var isPasswordVisible = false
        showRegisterPasswordButton.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                registerPasswordEditText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                showRegisterPasswordButton.setImageResource(R.drawable.baseline_visibility_24)
            } else {
                registerPasswordEditText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                showRegisterPasswordButton.setImageResource(R.drawable.baseline_visibility_off_24)
            }
            registerPasswordEditText.setSelection(registerPasswordEditText.text.length)
        }

        var isPaswordVisible = false
        showConfirmPasswordButton.setOnClickListener {
            isPaswordVisible = !isPaswordVisible
            if (isPaswordVisible) {
                confirmPasswordEditText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                showConfirmPasswordButton.setImageResource(R.drawable.baseline_visibility_24)
            } else {
                confirmPasswordEditText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                showConfirmPasswordButton.setImageResource(R.drawable.baseline_visibility_off_24)
            }
            confirmPasswordEditText.setSelection(registerPasswordEditText.text.length)
        }

        registerSubmitButton.setOnClickListener {
            val email = registerEmailEditText.text.toString()
            val password = registerPasswordEditText.text.toString()
            val confirmPassword = confirmPasswordEditText.text.toString()

            if (password == confirmPassword && password.length >= 7) {
                val sharedPref = activity?.getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)
                sharedPref?.edit()?.apply {
                    putString("EMAIL", email)
                    putString("PASSWORD", password)
                    apply()
                }
                findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
            } else {
                if (password != confirmPassword) {
                    confirmPasswordEditText.error = "Password tidak cocok"
                }
                if (password.length < 7) {
                    registerPasswordEditText.error = "Password minimal 7 karakter"
                }
            }
        }
        loginButton.setOnClickListener {
            findNavController().navigate(R.id.action_registerFragment_to_loginFragment)
        }

        return view
    }
}