package com.example.projectcapstone.login

import android.content.Context
import android.os.Bundle
import android.text.InputType
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import androidx.navigation.fragment.findNavController
import com.example.projectcapstone.R

class LoginFragment : Fragment() {
    private lateinit var emailEditText: EditText
    private lateinit var passwordEditText: EditText
    private lateinit var showPasswordButton: ImageButton
    private lateinit var loginButton: Button
    private lateinit var registerButton: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_login, container, false)
        emailEditText = view.findViewById(R.id.emailEditText)
        passwordEditText = view.findViewById(R.id.passwordEditText)
        showPasswordButton = view.findViewById(R.id.showPasswordButton)
        loginButton = view.findViewById(R.id.submitLoginButton)
        registerButton = view.findViewById(R.id.registerButton)

        var isPasswordVisible = false
        showPasswordButton.setOnClickListener {
            isPasswordVisible = !isPasswordVisible
            if (isPasswordVisible) {
                passwordEditText.inputType = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                showPasswordButton.setImageResource(R.drawable.baseline_visibility_24)
            } else {
                passwordEditText.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                showPasswordButton.setImageResource(R.drawable.baseline_visibility_off_24)
            }
            passwordEditText.setSelection(passwordEditText.text.length)
        }

        registerButton.setOnClickListener {
            findNavController().navigate(R.id.action_loginFragment_to_registerFragment)
        }
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sharedPref = activity?.getSharedPreferences("USER_DATA", Context.MODE_PRIVATE)

        // check email dan password yang disimpan diLokal
        val savedEmail = sharedPref?.getString("EMAIL", null)
        val savedPassword = sharedPref?.getString("PASSWORD", null)

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Validasi password dan email
            if (email == savedEmail && password == savedPassword) {
                // pindah page
                findNavController().navigate(R.id.action_loginFragment_to_navigation_home)
            } else {
                // Show erorr
                if (email != savedEmail) {
                    emailEditText.error = "Email tidak ditemukan"
                }
                if (password != savedPassword) {
                    passwordEditText.error = "Password salah"
                }
            }
        }
    }
}