package com.example.projectcapstone.ui.informasi

class InformasiViewModel {
}