package com.example.projectcapstone.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.projectcapstone.R
import com.example.projectcapstone.databinding.FragmentHomeBinding
import com.example.projectcapstone.ui.calculator.CalculatorActivity
import com.example.projectcapstone.ui.informasi.InformasiActivity

class HomeFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        // Bind tombol
        val btnCalculatorGizi: Button = view.findViewById(R.id.btnCalculatorGizi)
        val btnInformasiGizi: Button = view.findViewById(R.id.btnInformasiGizi)

        // Navigasi ke Activity Calculator Gizi
        btnCalculatorGizi.setOnClickListener {
            val intent = Intent(requireContext(), CalculatorActivity::class.java)
            startActivity(intent)
        }

        // Navigasi ke Activity Informasi Gizi
        btnInformasiGizi.setOnClickListener {
            val intent = Intent(requireContext(), InformasiActivity::class.java)
            startActivity(intent)
        }

        return view
    }
}